<?php
 
/*

Plugin Name: Hairspaces Around Dashes

Description: This simple but effective plugin converts spaces around dashes (both em and en dashes) into hairspaces.

Version: 1.0.0

Author: James Smith

Author URI: https://golangprojectstructure.com/

License: GPLv2 or later

Text Domain: hairspaces-around-dashes
 
*/

function hairspacer_enqueue_scripts() {
	wp_register_script(
		"hairspaces-around-dashes",
		plugin_dir_url( __FILE__ ) . "/scripts/hairspaces-around-dashes.js",
		null,
		"1.0.0",
		true,
	);

	wp_enqueue_script( "hairspaces-around-dashes" );
}

add_action( "wp_enqueue_scripts", "hairspacer_enqueue_scripts" );

?>