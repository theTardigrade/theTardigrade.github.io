(function() {

	var hairSpace = "\u200a";

	function handleTextNode(node) {
		var s,
			node2;

		if (node.parentNode) {
			s = (node.textContent || node.innerText || "").replace(/(\s)?(—|–)(\s)?/g, function(match, p1, p2, p3) {
				if (!p1 && !p3) {
					return p2;
				}

				if (!p1) {
					return p2 + hairSpace;
				}

				if (!p3) {
					return hairSpace + p2;
				}

				return hairSpace + p2 + hairSpace;
			});

			node2 = document.createTextNode(s);

			node.parentNode.replaceChild(node2, node);
		}
	}

	function recursiveWalkFromNode(node) {
		var childNodes,
			childNodesLength,
			n,
			i;

		if (node) {
			childNodes = node.childNodes;
			childNodesLength = childNodes.length;

			for (i = 0; i < childNodesLength; ++i) {
				n = childNodes[i];

				if (n) {
					if (n.nodeType === 3) {
						handleTextNode(n);
					} else if (n.nodeType === 1) {
						recursiveWalkFromNode(n);
					}
				}
			}
		}
	}

	function start() {
		recursiveWalkFromNode(document.body);
	}

	try {
		window.addEventListener("load", function() {
			start();
		}, false);
	} catch(e) {
		(function() {
			var t = +(new Date());

			(function wait() {
				switch (document.readyState) {
					case "complete":
						start();
					break;
					default:
						if ((+(new Date())) - t > 19999) {
							start();
						} else {
							setTimeout(wait, 10);
						}
				}
			})();
		})();
	}
})();