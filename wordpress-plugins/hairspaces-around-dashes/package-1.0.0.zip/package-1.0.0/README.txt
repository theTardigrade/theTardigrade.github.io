=== Plugin Name ===
Contributors: golang
Tags: dash, hairspace, space, whitespace, punctuation, design, style, typography, typesetting, dashes, spaces, spacing
Tested up to: 5.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This simple but effective plugin converts spaces around dashes (both em and en dashes) into hairspaces.

=== Description ===

Dashes are punctuation marks that are commonly used in written text. A long dash (—) is known as an em dash, whereas a short dash (–) is known as an en dash.

This plugin converts any whitespace around dashes into smaller hairspaces, to produce a more elegant typographic effect.

Both em and en dashes are recognized.

Look at the following sentence, which uses dashes:

> I love this plugin — and everything about it — because it works so well.

When this plugin is activated, the sentence would appear like this (with smaller spaces around the dashes):

> I love this plugin — and everything about it — because it works so well.